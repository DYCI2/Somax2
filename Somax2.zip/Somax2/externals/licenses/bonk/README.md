# Bonk~
The external `bonk~` included in this package was originally downloaded from https://github.com/v7b1/bonk_64bit-version, where the source code can be found.

In accordance with its license agreement, the original license is reproduced in its entirety in the `LICENSE` file in this folder.
