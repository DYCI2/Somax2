# ircamdescriptor~
The ircamdescriptor~ external is distributed as part of the [pipo](https://github.com/Ircam-RnD/pipo) where source code and license information can be found.